<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>
<!-- BEGIN .ministries-wrapper -->
						<div class="ministries-wrapper ministries-single">

							<ul>
								<li class="image"><a href="#"><img src="http://nabcaonline.org/wp-content/uploads/2011/08/history01.jpg" alt="" width="435" height="250" /></a></li>
								<li class="text">
									<h2>NABCA begins </h2>
									<p>As with all  organizations, several years preceded the formal establishment of the National  Association of Black Catholic Administrators [NABCA]. Between 1970 and 1976,  Diocesan Bishops opened Offices for Black Ministry [OBMs] in Detroit,  Rochester, Cincinnati,  Pittsburgh, Washington,  DC, and Houston.  Garland Jaggers, Detroit�s Director, and Father  Jerome Robinson, OP, Rochester�s  Director, gave birth to the idea for a gathering of OBM Directors for mutual  support and sharing. Five Directors had the first recorded meeting of the Black  Catholic Administrators on October 7 and 8, 1976 in Rochester, NY.  Diocesan Black Catholic leadership was necessary to impact Diocesan structures  and policies from within. They were surviving in unwelcoming and sometimes  hostile Diocesan structures, and among some disapproving African American  Catholics.</p>
									
								</li>
								<li class="spacer">&nbsp;</li>
								<li class="image"><a href="#"><img src="http://nabcaonline.org/wp-content/uploads/2011/08/history02.jpg" alt="" width="435" height="250" /></a></li>

								<li class="text"><h2>Closed Doors </h2>
									<p> Although their Bishops had established the offices, doors were not  always open. There was no handbook or job description except those the new  Directors fashioned for themselves through their discussions, personal  expertise, and organizational experiences. They mentored each other, expanded  local leadership, and in 1985 NABCA became incorporated in Ohio. Since 1977, the Director of the  National Office for Black Catholics [NOBC] was a member of NABCA. The NOBC, and  later, the Bishops� Conference, sought and received NABCA�s intervention to  help resolve NOBC organizational issues and concerns through the 1980s.</p>
									<p>                                               </p>
									
								</li>
								<li class="spacer">&nbsp;</li>
								<li class="image"><a href="#"><img src="http://nabcaonline.org/wp-content/uploads/2011/08/history03.jpg" alt="" /></a></li>
								<li class="text"><h2>First Bylaws</h2>

									<p>During the past 30 years, the first  bylaws were approved. There were consultations on the US Bishops� documents,  and with the Apostolic Delegate. Approving the vision of Mr. Lawrence Payne,  then Houston OBM Director in 1984, NABCA began discussions and plans for a  NABCA conference of Black Catholics on racism and evangelization. By 1985,  NABCA changed the name to a National Black Catholic Congress for 300 people.  Out of these first small efforts, came the present-day National Black Catholic  Congress which includes representatives from national Black Catholic  organizations. NABCA has continued its connection with the Congresses and  members have been active participants, supporters and implementers of the plans  and ministries that evolved. NABCA also collaborates with Region V to sponsor  the Interregional African American Catholic Evangelization Conference that now  includes several other regions. By 1996, NABCA had renewed its status as a tax  exempt organization.<br />
                                      <br />
                                      <br />
								  </p>
									
								</li>
								<li class="spacer">&nbsp;</li>
								<li class="image"><a href="#"><img src="http://nabcaonline.org/wp-content/uploads/2011/08/history04.jpg" alt="" /></a></li>
								<li class="text">

								<h2>Core Agenda Remains</h2>
									<p>Situations of OBMs change, but  NABCA�s core agenda remain: prayer and the Mass; in-service training; sharing  plans, ideas and priority national issues; and charitable service. Affiliated  members of NABCA, such as the Executive Director of the Secretariat for African  American Catholics in the US  Bishops� Conference, and the Director of the National Black Catholic Congress  are indicative of the growth of African American leadership. There had been a  growing number of Diocesan multicultural or ethnic ministries and other offices  that include or are directed by African American Catholics. In the 1980s and  1990s, NABCA offered its first publication, <em>Guidelines  for the Establishment of Offices of Black Catholic Ministries in Dioceses and  Archdioceses, </em>and a <em>Guideline for  Mentoring.</em></p>
									<p>            </p>
									
								</li>
								<li class="spacer">&nbsp;</li>
								<li class="image"><a href="#"><img src="http://nabcaonline.org/wp-content/uploads/2011/08/history05.jpg" alt="" width="435" height="250" /></a></li>

								<li class="text">
								<h2>Dedicated to Ministry</h2>
									<p>Despite the decreasing numbers of  OBMs, NABCA is still dedicated to ministry among African Americans within the  Roman Catholic Church; and growth in African American leadership and  participation at all levels in the Church. </p>
									
								</li>
								<li class="spacer">&nbsp;</li>
								<li class="image"><a href="#"></a></li>
								<li class="text">
								  
								</li>

							</ul>
						<!-- END .ministries-wrapper -->
					  </div>
</body>
</html>
