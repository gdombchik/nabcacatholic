<?php
include("inc/common.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<!-- BEGIN html -->
<html xmlns="http://www.w3.org/1999/xhtml">

	<!-- BEGIN head -->
	<head>
	
		<!-- Title -->
		<title>pageName<? echo $pageTitle ?></title>
		
		<!-- Meta Tags -->
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		
		<!-- Favicon -->
		<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />
		
		<!-- Stylesheets -->
		<link rel="stylesheet" href="css/style.css" type="text/css" />
		
		<!-- JavaScripts -->
		<script src="js/cufon-yui.js" type="text/javascript"></script>
		<script src="js/chaparralpro.font.js" type="text/javascript"></script>
		
		<script type="text/javascript">
			Cufon.replace('.title', { textShadow: '#fff 0 1px', hover: 'true' } );
			Cufon.replace('.menu-item a', { textShadow: '#110d0b 0 1px', hover: 'true' } );
			Cufon.replace('.block-1 h2 span', { textShadow: '#fff 0 1px' } );
			Cufon.replace('.block-2 h2 span', { textShadow: '#fff 0 1px' } );
			Cufon.replace('.footer-wrapper .footer table h2', { textShadow: '#201913 0 1px' } );
			Cufon.replace('.section-spacer span', { textShadow: '#fff 0 1px' } );
			Cufon.replace('.news-item .text h2', { textShadow: '#fff 0 1px', hover: 'true' } );
			Cufon.replace('.full-width-wrapper h2', { textShadow: '#fff 0 1px', hover: 'true' } );
			Cufon.replace('.full-width-title h2', { textShadow: '#fff 0 1px', hover: 'true' } );
			Cufon.replace('.gallery .title h2', { textShadow: '#fff 0 1px', hover: 'true' } );
			Cufon.replace('.gallery .open-title h1', { textShadow: '#fff 0 1px', hover: 'true' } );
		</script>

		<!--[if lte IE 7]>
		<style type="text/css">
			html .jqueryslidemenu { height: 1%; } /* Holly Hack for IE7 and below */
		</style>
		<![endif]-->

	<!-- END head -->
	<style type="text/css">
<!--
.style1 {font-size: 16px}
-->
    </style>
	</head>
	
	<!-- BEGIN body -->
	<body>
	
	
		<!-- BEGIN .container -->
		<div class="container">
		
		
		<!-- begin  H E A D E R    S E C T I O N -->

		<?php include("inc/header.php"); ?>
			
		<!-- end  H E A D E R    S E C T I O N -->
			
			
			<!-- BEGIN .menu-primary-wrapper -->
			<div class="menu-primary-wrapper">
			
			
				<!-- BEGIN .menu-primary -->
				<div class="menu-primary">
				<? include("inc/menu.php"); ?>
					
					<!-- BEGIN .social -->
					<? include("inc/social.php"); ?>
					<!-- END .social -->
					
				<!-- END .menu-primary -->
				</div>


			<!-- END .menu-primary-wrapper -->
			</div>


			<!-- BEGIN .content-wrapper -->
			<div class="content-wrapper">
			
				<!-- BEGIN .content -->
				<div class="content">
					
					
					<!-- BEGIN .full-width-wrapper -->
					<div class="full-width-wrapper">

						<!-- BEGIN .title -->
						<div class="full-width-title">
							<a href="#" class="back"><b>back to Homepage</b></a>
							<h2><a href="#">Board of Directors </a></h2>
						    <!-- END .title -->	
						</div>
						
						<!-- BEGIN .ministries-wrapper -->
						<div class="ministries-wrapper ministries-four">
							<ul>
								<li class="image">
								  <img src="http://nabcaonline.com/wp-content/uploads/2011/10/DeaconArtMiller2_200x270.jpg" alt="" width="200" height="270" />
									<h2><a href="#" class="style1">Deacon Art Miller </a></h2>
									<p>PRESIDENT</p>
									<p></p>
								</li>
								<li class="image">
								  <img src="http://nabcaonline.com/wp-content/uploads/2011/10/Charles-O-Prejean-Sr200x270.jpg" alt="" width="200" height="270" />
									<h2><a href="#" class="style1">Charles O. Prejean, Sr. </a></h2>
									<p>VICE PRESIDENT</p>
									<p></p>
								</li>
								<li class="image">
								  <img src="http://nabcaonline.com/wp-content/uploads/2011/10/Johnnie-Dorsey200x270.jpg" alt="" width="200" height="270" />
									<h2><a href="#" class="style1">Johnnie Dorsey, Sr. </a></h2>
									<p>TREASURER</p>
									<p></p>
								</li>
								<li class="image">
								  <img src="http://nabcaonline.com/wp-content/uploads/2011/10/aaBlank200x270.jpg" alt="" width="200" height="270" />
									<h2><a href="#" class="style1">Judge Arthur McFarland </a></h2>
									<p>PARLIAMENTARIAN</p>
									<p></p>
								</li>
								
								<li class="spacer">&nbsp;</li>
								
								<li class="image"><img src="http://nabcaonline.com/wp-content/uploads/2011/10/aaBlank200x270.jpg" alt="" width="200" height="270" />
								  <h2><a href="#" class="style1">Linda LaCour </a></h2>
									<p>CHAIR OF THE ANNUAL MEETING </p>
									<p></p>
								</li>
								<li class="image"><img src="http://nabcaonline.com/wp-content/uploads/2011/10/aaBlank200x270.jpg" alt="" width="200" height="270" />
								  <h2><a href="#" class="style1">Gwen Summers </a></h2>
									<p>REGIONS 1, 2 AND 3 </p>
									<p></p>
								</li>
								<li class="image"><img src="http://nabcaonline.com/wp-content/uploads/2011/10/DeaconAlTurner200x270.jpg" alt="" width="200" height="270" />
								  <h2><a href="#" class="style1">Deacon Al Turner </a></h2>
									<p>REGION 4 </p>
									<p></p>
								</li>
								<li class="image">
								  <img src="http://nabcaonline.com/wp-content/uploads/2011/10/Annette-Turner200x270.jpg" alt="" width="200" height="270" />
									<h2><a href="#" class="style1">M. Annette Turner </a></h2>
									<p>REGION 5 </p>
									<p></p>
								</li>
								
								<li class="spacer">&nbsp;</li>
								
								<li class="image"><img src="http://nabcaonline.com/wp-content/uploads/2011/10/aaBlank200x270.jpg" alt="" width="200" height="270" />
								  <h2><a href="#" class="style1">Linda LaCour </a></h2>
									<p>REGION 6 </p>
									<p></p>
								</li>
								<li class="image"><img src="http://nabcaonline.com/wp-content/uploads/2011/10/aaBlank200x270.jpg" alt="" width="200" height="270" />
								  <h2><a href="#" class="style1">- VACANT - </a></h2>
									<p>REGION 7 </p>
									<p></p>
								</li>
								<li class="image"><img src="http://nabcaonline.com/wp-content/uploads/2011/10/aaBlank200x270.jpg" alt="" width="200" height="270" />
								  <h2><a href="#" class="style1">- VACANT - </a></h2>
									<p>REGION 8 </p>
									<p></p>
								</li>
								<li class="image">
								  <img src="http://nabcaonline.com/wp-content/uploads/2011/10/aaBlank200x270.jpg" alt="" width="200" height="270" />
									<h2><a href="#" class="style1">- VACANT -  </a></h2>
									<p>REGION 9 </p>
									<p></p>
								</li>
								
								<li class="spacer">&nbsp;</li>
								
								<li class="image">
								  <img src="http://nabcaonline.com/wp-content/uploads/2011/10/CarolWhite200x270.jpg" alt="" width="200" height="270" />
									<h2><a href="#" class="style1">Carol White </a></h2>
									<p>REGION 10 </p>
							  </li>
								<li class="image">
								  <img src="http://nabcaonline.com/wp-content/uploads/2011/10/MaryLeisring200x270.jpg" alt="" width="200" height="270" />
									<h2><a href="#" class="style1">Mary Leisring </a></h2>
									<p>REGION 12, 13 </p>
									<p></p>
							  </li>
								<li class="image"><img src="http://nabcaonline.com/wp-content/uploads/2011/10/SrPatHaley_2_200x270.jpg" alt="" width="200" height="270" />
								  <h2><a href="#" class="style1">Sr. Patricia Haley, SCN </a></h2>
								  <p>REGION 14 </p>
								  <h2 class="style1">&nbsp;</h2>
									<p></p>
							  </li>
								<li class="image">
								  <p></p>
							  </li>
							</ul>
						<!-- END .ministries-wrapper -->
					  </div>

					<!-- END .full-width-wrapper -->	
					</div>


				<!-- END .content -->
				</div>
				
			<!-- END .content-wrapper -->
			</div>
			
			
			<div class="clear-footer"></div>
			
		<!-- END .container -->
		</div>
		
		
		<!--start F O O T E R    S E C T I O N-->
		<?php
		include("inc/footer.php");
		?>
		
		<!--end F O O T E R    S E C T I O N-->

	</body>
</html>