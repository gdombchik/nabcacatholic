<?php
include("inc/common.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<!-- BEGIN html -->
<html xmlns="http://www.w3.org/1999/xhtml">

	<!-- BEGIN head -->
	<head>
	
		<!-- Title -->
		<title>pageName<? echo $pageTitle ?></title>
		
		<!-- Meta Tags -->
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		
		<!-- Favicon -->
		<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />
		
		<!-- Stylesheets -->
		<link rel="stylesheet" href="css/style.css" type="text/css" />
		
		<!-- JavaScripts -->
		<script src="js/cufon-yui.js" type="text/javascript"></script>
		<script src="js/chaparralpro.font.js" type="text/javascript"></script>
		
		<script type="text/javascript">
			Cufon.replace('.title', { textShadow: '#fff 0 1px', hover: 'true' } );
			Cufon.replace('.menu-item a', { textShadow: '#110d0b 0 1px', hover: 'true' } );
			Cufon.replace('.block-1 h2 span', { textShadow: '#fff 0 1px' } );
			Cufon.replace('.block-2 h2 span', { textShadow: '#fff 0 1px' } );
			Cufon.replace('.footer-wrapper .footer table h2', { textShadow: '#201913 0 1px' } );
			Cufon.replace('.section-spacer span', { textShadow: '#fff 0 1px' } );
			Cufon.replace('.news-item .text h2', { textShadow: '#fff 0 1px', hover: 'true' } );
			Cufon.replace('.full-width-wrapper h2', { textShadow: '#fff 0 1px', hover: 'true' } );
			Cufon.replace('.full-width-title h2', { textShadow: '#fff 0 1px', hover: 'true' } );
			Cufon.replace('.gallery .title h2', { textShadow: '#fff 0 1px', hover: 'true' } );
			Cufon.replace('.gallery .open-title h1', { textShadow: '#fff 0 1px', hover: 'true' } );
		</script>

		<!--[if lte IE 7]>
		<style type="text/css">
			html .jqueryslidemenu { height: 1%; } /* Holly Hack for IE7 and below */
		</style>
		<![endif]-->

	<!-- END head -->
	</head>
	
	<!-- BEGIN body -->
	<body>
	
	
		<!-- BEGIN .container -->
		<div class="container">
		
		
		<!-- begin  H E A D E R    S E C T I O N -->

		<?php include("inc/header.php"); ?>
			
		<!-- end  H E A D E R    S E C T I O N -->
			
			
			<!-- BEGIN .menu-primary-wrapper -->
			<div class="menu-primary-wrapper">
			
			
				<!-- BEGIN .menu-primary -->
				<div class="menu-primary">
				<? include("inc/menu.php"); ?>
					
					<!-- BEGIN .social -->
					<? include("inc/social.php"); ?>
					<!-- END .social -->
					
				<!-- END .menu-primary -->
				</div>


			<!-- END .menu-primary-wrapper -->
			</div>


			<!-- BEGIN .content-wrapper -->
			<div class="content-wrapper">
			
				<!-- BEGIN .content -->
				<div class="content">
					
					
					<!-- BEGIN .full-width-wrapper -->
					<div class="full-width-wrapper">

						<!-- BEGIN .title -->
						<div class="full-width-title">
							<a href="#" class="back"><b>back to Homepage</b></a>
							<h2><a href="#">Ministries - Three Column View</a></h2>
						<!-- END .title -->	
						</div>
						
						<!-- BEGIN .ministries-wrapper -->
						<div class="ministries-wrapper ministries-three">
							<ul>
								<li class="image">
									<a href="#"><img src="images/image-45.jpg" alt="" /></a>
									<h2><a href="#">Vestibulum posuere</a></h2>
									<p>Fusce eleifend fermentum est, quis accumsan enim elementum vitae. Mae cenas accumsan, sem nec ullamcorper feugiat, eros ligula placerat tellus.</p>
									<p><a href="#" class="more-link">Read more</a></p>
								</li>
								<li class="image">
									<a href="#"><img src="images/image-46.jpg" alt="" /></a>
									<h2><a href="#">Pellentesque habitant</a></h2>
									<p>Suspendisse sit amet magna sed quam porta lobortis et sit amet leo. Vivamus et vulputate nisl. Mauris ullamcorper, mauris quis elementum.</p>
									<p><a href="#" class="more-link">Read more</a></p>
								</li>
								<li class="image">
									<a href="#"><img src="images/image-47.jpg" alt="" /></a>
									<h2><a href="#">Lorem ipsum</a></h2>
									<p>Vestibulum elit purus, molestie sit amet bibendum porta, ultrices in nunc. Ut eu mattis elit. Fusce lorem massa, congue sit. Accumsan nulla purus.</p>
									<p><a href="#" class="more-link">Read more</a></p>
								</li>
								<li class="spacer">&nbsp;</li>
								<li class="image">
									<a href="#"><img src="images/image-48.jpg" alt="" /></a>
									<h2><a href="#">Dolor sit amet</a></h2>
									<p>Proin sem mauris, dignissim sed vestibulum at, vestibulum nec nisi. Duis sollicitudin eros ut felis ultrices non luctus neque scelerisque.</p>
									<p><a href="#" class="more-link">Read more</a></p
								></li>
								<li class="image">
									<a href="#"><img src="images/image-49.jpg" alt="" /></a>
									<h2><a href="#">Aliquam consectetur</a></h2>
									<p>Maecenas accumsan, sem nec ullamcorper feugiat, eros ligula placerat tellus, rutrum auctor sapien augue eu nulla. Fusce eleifend fermentum.</p>
									<p><a href="#" class="more-link">Read more</a></p>
								</li>
								<li class="image">
									<a href="#"><img src="images/image-50.jpg" alt="" /></a>
									<h2><a href="#">Vestibulum et purus</a></h2>
									<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer et velit nulla, id pretium quam. Aliquam dictum, massa molestie.</p>
									<p><a href="#" class="more-link">Read more</a></p>
								</li>
							</ul>
						<!-- END .ministries-wrapper -->
						</div>

					<!-- END .full-width-wrapper -->	
					</div>


				<!-- END .content -->
				</div>
				
			<!-- END .content-wrapper -->
			</div>
			
			
			<div class="clear-footer"></div>
			
		<!-- END .container -->
		</div>
		
		
		<!--start F O O T E R    S E C T I O N-->
		<?php
		include("inc/footer.php");
		?>
		
		<!--end F O O T E R    S E C T I O N-->

	</body>
</html>