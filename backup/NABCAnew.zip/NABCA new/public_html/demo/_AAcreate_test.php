						<!-- BEGIN .ministries-wrapper -->
						<div class="ministries-wrapper ministries-two">
							<ul>
								<li class="image">
									<a href="#"></a>
									<h2><a href="#">National  </a></h2>
									<p><br />
									  <br />
                                      <a href="#"></a> </p>
									<h2><a href="#">President</a></h2>
									<p>Deacon Arthur Miller </p>
								  <p><br />  
								  <a href="#"></a> </p>
									<h2><a href="#">Vice President </a></h2>
									<p>Charles Prejean <br />
									  <br />
									  <a href="#"></a> </p>
									<h2><a href="#">Treasurer</a></h2>
									<p>Johnnie D. Dorsey, Sr. <br />
									  <br />
									</p>
									<h2><a href="#">Parliamentarian</a></h2>
									<p>Judge Arthur McFarland <br />
									  <br />
									  <br />
									</p>
									<h2><a href="#">Chair of Annual Meeting </a></h2>
									<p>Linda D. LaCour</p>
								</li>
								<li class="image">
									<a href="#"></a>
									<h2><a href="#">Regional</a></h2>
									<p><br />
									  <br />
									</p>
									<h2><a href="#">Regions 1, 2, 3 </a></h2>
									<p>Gwen Summers <br />
									<br />
									</p>
									<h2><a href="#">Region 4 </a></h2>
									<p>Deacon Al Turner <br />
									  <br />
									</p>
									<h2><a href="#">Region 5 </a></h2>
									<p>M. Annette Turner </p>
							  </li>
							  <li class="image"></li>
								<li class="image">
								  <h2><a href="#">Region 6 </a></h2>
								  <p>Michael Youngblood<br />
								    <br />
								  </p>
							      <h2><a href="#">Regions 7, 8, 9 </a></h2>
							      <p>-vacant-<br />
					                <br />
							      </p>
							      <h2><a href="#">Region 10 </a></h2>
							      <p>Carol White <br />
							        <br />
							      </p>
							      <h2><a href="#">Regions 12, 13 </a></h2>
							      <p>Mary Leisring </p>
							      <p>&nbsp; </p>
							  </li>
								<li class="image"></li>
								<li class="spacer">&nbsp;</li>
								<li class="image"></li>
								<li class="image">
									<a href="#"></a>
									<h2>&nbsp;</h2>
							  </li>
								<li class="spacer">&nbsp;</li>
								<li class="image"></li>
								<li class="image">
									<a href="#"></a>
									<h2><a href="#">Curabitur ultricies sagittis lorem</a></h2>
									<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer et velit nulla, id </p>
							  </li>
							</ul>
						<!-- END .ministries-wrapper -->
					  </div>

					<!-- END .full-width-wrapper -->	
					</div>


				<!-- END .content -->
				</div>
				
			<!-- END .content-wrapper -->
			</div>
			
