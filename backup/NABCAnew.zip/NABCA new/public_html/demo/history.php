<?php
include("inc/common.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<!-- BEGIN html -->
<html xmlns="http://www.w3.org/1999/xhtml">

	<!-- BEGIN head -->
	<head>
	
		<!-- Title -->
		<title>History<? echo $pageTitle ?></title>
		
		<!-- Meta Tags -->
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		
		<!-- Favicon -->
		<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />
		
		<!-- Stylesheets -->
		<link rel="stylesheet" href="css/style.css" type="text/css" />
		
		<!-- JavaScripts -->
		<script src="js/cufon-yui.js" type="text/javascript"></script>
		<script src="js/chaparralpro.font.js" type="text/javascript"></script>
		
		<script type="text/javascript">
			Cufon.replace('.title', { textShadow: '#fff 0 1px', hover: 'true' } );
			Cufon.replace('.menu-item a', { textShadow: '#110d0b 0 1px', hover: 'true' } );
			Cufon.replace('.block-1 h2 span', { textShadow: '#fff 0 1px' } );
			Cufon.replace('.block-2 h2 span', { textShadow: '#fff 0 1px' } );
			Cufon.replace('.footer-wrapper .footer table h2', { textShadow: '#201913 0 1px' } );
			Cufon.replace('.section-spacer span', { textShadow: '#fff 0 1px' } );
			Cufon.replace('.news-item .text h2', { textShadow: '#fff 0 1px', hover: 'true' } );
			Cufon.replace('.full-width-wrapper h2', { textShadow: '#fff 0 1px', hover: 'true' } );
			Cufon.replace('.full-width-title h2', { textShadow: '#fff 0 1px', hover: 'true' } );
			Cufon.replace('.gallery .title h2', { textShadow: '#fff 0 1px', hover: 'true' } );
			Cufon.replace('.gallery .open-title h1', { textShadow: '#fff 0 1px', hover: 'true' } );
		</script>

		<!--[if lte IE 7]>
		<style type="text/css">
			html .jqueryslidemenu { height: 1%; } /* Holly Hack for IE7 and below */
		</style>
		<![endif]-->

	<!-- END head -->
	</head>
	
	<!-- BEGIN body -->
	<body>
	
	
		<!-- BEGIN .container -->
		<div class="container">
		
		
		<!-- begin  H E A D E R    S E C T I O N -->

		<?php include("inc/header.php"); ?>
			
		<!-- end  H E A D E R    S E C T I O N -->
			
			
			<!-- BEGIN .menu-primary-wrapper -->
			<div class="menu-primary-wrapper">
			
			
				<!-- BEGIN .menu-primary -->
				<div class="menu-primary">
				
					
				<? include("inc/menu.php"); ?>
					
					<!-- BEGIN .social -->
					<? include("inc/social.php"); ?>
					<!-- END .social -->

				<!-- END .menu-primary -->
					</div>



			<!-- END .menu-primary-wrapper -->
			</div>


			<!-- BEGIN .content-wrapper -->
			<div class="content-wrapper">
			
				<!-- BEGIN .content -->
				<div class="content">
					
					
					<!-- BEGIN .full-width-wrapper -->
					<div class="full-width-wrapper">

						<!-- BEGIN .title -->
						<div class="full-width-title">
							<a href="#" class="back"><b>back to Homepage</b></a>
							<h2><a href="#">History</a></h2>
						    <!-- END .title -->	
						</div>
						
						<!-- BEGIN .ministries-wrapper -->
						<div class="ministries-wrapper ministries-single">
							<ul>
								<li class="image"><a href="#"><img src="images/image-44.jpg" alt="" width="435" height="250" /></a></li>
								<li class="text">
									<h2>NABCA begins </h2>
									<p>As with all  organizations, several years preceded the formal establishment of the National  Association of Black Catholic Administrators [NABCA]. Between 1970 and 1976,  Diocesan Bishops opened Offices for Black Ministry [OBMs] in Detroit,  Rochester, Cincinnati,  Pittsburgh, Washington,  DC, and Houston.  Garland Jaggers, Detroit’s Director, and Father  Jerome Robinson, OP, Rochester’s  Director, gave birth to the idea for a gathering of OBM Directors for mutual  support and sharing. Five Directors had the first recorded meeting of the Black  Catholic Administrators on October 7 and 8, 1976 in Rochester, NY.  Diocesan Black Catholic leadership was necessary to impact Diocesan structures  and policies from within. They were surviving in unwelcoming and sometimes  hostile Diocesan structures, and among some disapproving African American  Catholics.</p>
									
								</li>
								<li class="spacer">&nbsp;</li>
								<li class="image"><a href="#"><img src="images/image-38.jpg" alt="" width="435" height="250" /></a></li>
								<li class="text"><h2>Closed Doors </h2>
									<p> Although their Bishops had established the offices, doors were not  always open. There was no handbook or job description except those the new  Directors fashioned for themselves through their discussions, personal  expertise, and organizational experiences. They mentored each other, expanded  local leadership, and in 1985 NABCA became incorporated in Ohio. Since 1977, the Director of the  National Office for Black Catholics [NOBC] was a member of NABCA. The NOBC, and  later, the Bishops’ Conference, sought and received NABCA’s intervention to  help resolve NOBC organizational issues and concerns through the 1980s.</p>
									<p>                                               </p>
									
								</li>
								<li class="spacer">&nbsp;</li>
								<li class="image"><a href="#"><img src="images/image-40.jpg" alt="" /></a></li>
								<li class="text"><h2>First Bylaws</h2>
									<p>During the past 30 years, the first  bylaws were approved. There were consultations on the US Bishops’ documents,  and with the Apostolic Delegate. Approving the vision of Mr. Lawrence Payne,  then Houston OBM Director in 1984, NABCA began discussions and plans for a  NABCA conference of Black Catholics on racism and evangelization. By 1985,  NABCA changed the name to a National Black Catholic Congress for 300 people.  Out of these first small efforts, came the present-day National Black Catholic  Congress which includes representatives from national Black Catholic  organizations. NABCA has continued its connection with the Congresses and  members have been active participants, supporters and implementers of the plans  and ministries that evolved. NABCA also collaborates with Region V to sponsor  the Interregional African American Catholic Evangelization Conference that now  includes several other regions. By 1996, NABCA had renewed its status as a tax  exempt organization.<br />
                                      <br />
                                      <br />
								  </p>
									
								</li>
								<li class="spacer">&nbsp;</li>
								<li class="image"><a href="#"><img src="images/image-41.jpg" alt="" /></a></li>
								<li class="text">
								<h2>Core Agenda Remains</h2>
									<p>Situations of OBMs change, but  NABCA’s core agenda remain: prayer and the Mass; in-service training; sharing  plans, ideas and priority national issues; and charitable service. Affiliated  members of NABCA, such as the Executive Director of the Secretariat for African  American Catholics in the US  Bishops’ Conference, and the Director of the National Black Catholic Congress  are indicative of the growth of African American leadership. There had been a  growing number of Diocesan multicultural or ethnic ministries and other offices  that include or are directed by African American Catholics. In the 1980s and  1990s, NABCA offered its first publication, <em>Guidelines  for the Establishment of Offices of Black Catholic Ministries in Dioceses and  Archdioceses, </em>and a <em>Guideline for  Mentoring.</em></p>
									<p>            </p>
									
								</li>
								<li class="spacer">&nbsp;</li>
								<li class="image"><a href="#"><img src="images/image-43.jpg" alt="" width="435" height="250" /></a></li>
								<li class="text">
								<h2>Dedicated to Ministry</h2>
									<p>Despite the decreasing numbers of  OBMs, NABCA is still dedicated to ministry among African Americans within the  Roman Catholic Church; and growth in African American leadership and  participation at all levels in the Church. </p>
									
								</li>
								<li class="spacer">&nbsp;</li>
								<li class="image"><a href="#"></a></li>
								<li class="text">
								  
								</li>
							</ul>
						<!-- END .ministries-wrapper -->
					  </div>

					<!-- END .full-width-wrapper -->	
					</div>


				<!-- END .content -->
				</div>
				
			<!-- END .content-wrapper -->
			</div>
			
			
			<div class="clear-footer"></div>
			
				<!-- END .container -->
		</div>
		
		<!--start F O O T E R    S E C T I O N-->
		<?php
		include("inc/footer.php");
		?>
		
		<!--end F O O T E R    S E C T I O N-->

	</body>
</html>