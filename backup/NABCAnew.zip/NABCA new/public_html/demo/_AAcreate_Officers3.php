<?php
include("inc/common.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<!-- BEGIN html -->
<html xmlns="http://www.w3.org/1999/xhtml">

	<!-- BEGIN head -->
	<head>
	
		<!-- Title -->
		<title>pageName<? echo $pageTitle ?></title>
		
		<!-- Meta Tags -->
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		
		<!-- Favicon -->
		<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />
		
		<!-- Stylesheets -->
		<link rel="stylesheet" href="css/style.css" type="text/css" />
		
		<!-- JavaScripts -->
		<script src="js/cufon-yui.js" type="text/javascript"></script>
		<script src="js/chaparralpro.font.js" type="text/javascript"></script>
		
		<script type="text/javascript">
			Cufon.replace('.title', { textShadow: '#fff 0 1px', hover: 'true' } );
			Cufon.replace('.menu-item a', { textShadow: '#110d0b 0 1px', hover: 'true' } );
			Cufon.replace('.block-1 h2 span', { textShadow: '#fff 0 1px' } );
			Cufon.replace('.block-2 h2 span', { textShadow: '#fff 0 1px' } );
			Cufon.replace('.footer-wrapper .footer table h2', { textShadow: '#201913 0 1px' } );
			Cufon.replace('.section-spacer span', { textShadow: '#fff 0 1px' } );
			Cufon.replace('.news-item .text h2', { textShadow: '#fff 0 1px', hover: 'true' } );
			Cufon.replace('.full-width-wrapper h2', { textShadow: '#fff 0 1px', hover: 'true' } );
			Cufon.replace('.full-width-title h2', { textShadow: '#fff 0 1px', hover: 'true' } );
			Cufon.replace('.gallery .title h2', { textShadow: '#fff 0 1px', hover: 'true' } );
			Cufon.replace('.gallery .open-title h1', { textShadow: '#fff 0 1px', hover: 'true' } );
		</script>

		<!--[if lte IE 7]>
		<style type="text/css">
			html .jqueryslidemenu { height: 1%; } /* Holly Hack for IE7 and below */
		</style>
		<![endif]-->

	<!-- END head -->
	</head>
	
	<!-- BEGIN body -->
	<body>
	
	
		<!-- BEGIN .container -->
		<div class="container">
		
		
		<!-- begin  H E A D E R    S E C T I O N -->

		<?php include("inc/header.php"); ?>
			
		<!-- end  H E A D E R    S E C T I O N -->		

			
			<!-- BEGIN .menu-primary-wrapper -->
			<div class="menu-primary-wrapper">
			
			
				<!-- BEGIN .menu-primary -->
				<div class="menu-primary">
				<? include("inc/menu.php"); ?>
					
					<!-- BEGIN .social -->
					<? include("inc/social.php"); ?>
					<!-- END .social -->		

				<!-- END .menu-primary -->
				</div>


			<!-- END .menu-primary-wrapper -->
			</div>


			<!-- BEGIN .content-wrapper -->
			<div class="content-wrapper">
			
				<!-- BEGIN .content -->
				<div class="content">
					
					
					<!-- BEGIN .full-width-wrapper -->
					<div class="full-width-wrapper">

						<!-- BEGIN .title -->
						<div class="full-width-title">
							<a href="#" class="back"><b>back to Homepage</b></a>
							<h2><a href="#">Ministries - Two Column View</a></h2>
						<!-- END .title -->	
						</div>
						
						<!-- BEGIN .ministries-wrapper -->
						<div class="ministries-wrapper ministries-two">
							<ul>
								<li class="image">
									<h2><a href="#">President</a></h2>
									<p>Deacon Arthur Miller</p>
							  </li>
								<li class="image">
									<a href="#"></a>
									<h2><a href="#">Regions 1, 2, 3</a></h2>
									<p>Gwen Summers  </p>
							  </li>
							  
							  
								<li class="spacer">&nbsp;</li>
								<li class="image">
									<a href="#"></a>
									<h2><a href="#">Vice President</a></h2>
									<p>Charles Prejean</p>
								</li>
								<li class="image">
									<a href="#"></a>
									<h2><a href="#">Region 4</a></h2>
									<p>Deacon Al Turner</p>
								</li>
								
								
								<li class="spacer">&nbsp;</li>
								<li class="image">
									<a href="#"></a>
									<h2><a href="#">Treasurer</a></h2>
									<p>Johnnie D. Dorsey, Sr.</p>
								</li>
								<li class="image">
									<a href="#"></a>
									<h2><a href="#"></a><a href="#">Region 5</a></h2>
									<p>M. Annette Turner </p>
								</li>
								
								
								<li class="spacer">&nbsp;</li>
								<li class="image">
									<a href="#"></a>
									<h2><a href="#">Parliamentarian</a></h2>
									<p>Judge Arthur McFarland</p>
								</li>
								<li class="image">
									<a href="#"></a>
									<h2><a href="#">Region 6</a></h2>
									<p>Michael Youngblood</p>
								</li>
								
								
								<li class="spacer">&nbsp;</li>
								<li class="image">
									<a href="#"></a>
									<h2><a href="#">Chair of Annual Meeting </a></h2>
									<p>Linda D. LaCour</p>
								</li>
								<li class="image">
									<a href="#"></a>
									<h2><a href="#">Regions 7, 8, 9</a></h2>
									<p>-vacant-</p>
								</li>
								
								<li class="spacer">&nbsp;</li>
								<li class="image">
									<a href="#"></a>
									<h2><a href="#"></a></h2>
									<p>&nbsp;</p>
								</li>
								<li class="image">
									<a href="#"></a>
									<h2><a href="#">Region 10</a></h2>
									<p>Carol White </p>
								</li>
								
								<li class="spacer">&nbsp;</li>
								<li class="image">
									<a href="#"></a>
									<h2><a href="#"></a></h2>
									<p>&nbsp;</p>
								</li>
								<li class="image">
									<a href="#"></a>
									<h2><a href="#">Regions 12, 13</a></h2>
									<p>Mary Leisring</p>
								</li>
								
								
							</ul>
						<!-- END .ministries-wrapper -->
					  </div>

					<!-- END .full-width-wrapper -->	
					</div>


				<!-- END .content -->
				</div>
				
			<!-- END .content-wrapper -->
			</div>
			
			
			<div class="clear-footer"></div>
			
		<!-- END .container -->
		</div>
		
		
		<!--start F O O T E R    S E C T I O N-->
		<?php
		include("inc/footer.php");
		?>
		
		<!--end F O O T E R    S E C T I O N-->

	</body>
</html>