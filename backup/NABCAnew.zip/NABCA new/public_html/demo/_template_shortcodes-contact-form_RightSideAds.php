<?php
include("inc/common.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<!-- BEGIN html -->
<html xmlns="http://www.w3.org/1999/xhtml">

	<!-- BEGIN head -->
	<head>
	
		<!-- Title -->
		<title>pageName<? echo $pageTitle ?></title>
		
		<!-- Meta Tags -->
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		
		<!-- Favicon -->
		<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />
		
		<!-- Stylesheets -->
		<link rel="stylesheet" href="css/style.css" type="text/css" />
		<link rel="stylesheet" href="css/shortcodes.css" type="text/css" />
		
		<!-- JavaScripts -->
		<script src="js/cufon-yui.js" type="text/javascript"></script>
		<script src="js/chaparralpro.font.js" type="text/javascript"></script>
		
		<script type="text/javascript">
			Cufon.replace('.title', { textShadow: '#fff 0 1px', hover: 'true' } );
			Cufon.replace('.menu-item a', { textShadow: '#110d0b 0 1px', hover: 'true' } );
			Cufon.replace('.block-1 h2 span', { textShadow: '#fff 0 1px' } );
			Cufon.replace('.block-2 h2 span', { textShadow: '#fff 0 1px' } );
			Cufon.replace('.footer-wrapper .footer table h2', { textShadow: '#201913 0 1px' } );
			Cufon.replace('.section-spacer span', { textShadow: '#fff 0 1px' } );
			Cufon.replace('.news-item .text h2', { textShadow: '#fff 0 1px', hover: 'true' } );
			Cufon.replace('.article-wrapper .text h2, .article-wrapper .text h3, .article-wrapper .text h4, .article-wrapper .text h5, .article-wrapper .text h6', { textShadow: '#fff 0 1px', hover: 'true' } );
			Cufon.replace('.article-wrapper blockquote', { textShadow: '#fff 0 1px', hover: 'true' } );
			Cufon.replace('.section-header h2', { textShadow: '#fff 0 1px', hover: 'true' } );
		</script>

		<!--[if lte IE 7]>
		<style type="text/css">
			html .jqueryslidemenu { height: 1%; } /* Holly Hack for IE7 and below */
		</style>
		<![endif]-->

	<!-- END head -->
	</head>
	
	<!-- BEGIN body -->
	<body>
	
	
		<!-- BEGIN .container -->
		<div class="container">
		
		
					<!-- begin  H E A D E R    S E C T I O N -->

		<?php include("inc/header.php"); ?>
			
		<!-- end  H E A D E R    S E C T I O N -->
			
			
			<!-- BEGIN .menu-primary-wrapper -->
			<div class="menu-primary-wrapper">
			
			
				<!-- BEGIN .menu-primary -->
				<div class="menu-primary">
				<? include("inc/menu.php"); ?>
					
					<!-- BEGIN .social -->
					<? include("inc/social.php"); ?>
					<!-- END .social -->
					
				<!-- END .menu-primary -->
				</div>


			<!-- END .menu-primary-wrapper -->
			</div>


			<!-- BEGIN .content-wrapper -->
			<div class="content-wrapper">
			
				<!-- BEGIN .content -->
				<div class="content">
				
					
					<!-- BEGIN .left-side -->
					<div class="left-side">
					
						<!-- BEGIN .section-header -->
						<div class="section-header">
							<h2>Shortcode Contact Form</h2>
						<!-- END .menu-primary-wrapper -->
						</div>
						
						
						<!-- BEGIN .shortcodes-wrapper -->
						<div class="shortcodes-wrapper shortcodes-contact-form">
							
							<form action="" class="contact-form">
								<table>
									<tr>
										<td class="label">Name:</td>
										<td><input type="text" class="input-text" /></td>
									</tr>
									<tr><td class="spacer" colspan="2"></td></tr>
									<tr>
										<td class="label">E-mail:</td>
										<td><input type="text" class="input-text" /></td>
									</tr>
									<tr><td class="spacer" colspan="2"></td></tr>
									<tr>
										<td class="label">Phone:</td>
										<td><input type="text" class="input-text" /></td>
									</tr>
									<tr><td class="spacer" colspan="2"></td></tr>
									<tr>
										<td class="label">Your comment:</td>
										<td>
											<table class="text-area">
												<tr>
													<td class="top">
														<textarea></textarea>
													</td>
												</tr>
												<tr><td class="bottom"></td></tr>
											</table>
										</td>
									</tr>
									<tr><td class="spacer" colspan="2"></td></tr>
									<tr>
										<td></td>
										<td><a href="#" class="btn-1 btn-align-left"><i>&nbsp;</i><b><span>Send contact form</span></b><u>&nbsp;</u></a></td>
									</tr>
								</table>
							</form>

						<!-- END .shortcodes-wrapper -->
						</div>


						<!-- BEGIN .list-footer -->
						<div class="list-footer list-footer-dashed">
							<a href="#" class="btn-1 btn-align-left btn-previous"><i>&nbsp;</i><b><span>Back to homepage</span></b><u>&nbsp;</u></a>
						<!-- END .list-footer -->
						</div>
						
					
					<!-- END .left-side -->
					</div>
					
					
					<!-- BEGIN .right-side -->
					<div class="right-side">
					
					
						<!-- BEGIN .block-1 -->
						<div class="block-1">
							<h2><span>Latest entries</span><a href="#"><b>show all</b></a></h2>
							<div class="block-1-content">
							
								<!-- BEGIN .latest-events -->
								<div class="latest-events">
								
									<!-- BEGIN .latest-event-item -->
									<div class="latest-event-item">
										<h3><a href="#">Aliquam in condimentum augue</a></h3>
										<p>Cras vulputate dui at felis varius et consec tetur risus viverra. Vivamus commodo gravida malesuada.</p>
										<a href="#" class="more-link">Read more</a>
									<!-- END .latest-event-item -->
									</div>
									
									<!-- BEGIN .latest-event-item -->
									<div class="latest-event-item">
										<h3><a href="#">Maecenas lacinia diam vel elit</a></h3>
										<p>Phasellus urna sem, scelerisque ac porta a, fringilla non neque. Mauris lacus eros, faucibus quis rhoncus sit amet, adipiscing.</p>
										<a href="#" class="more-link">Read more</a>
									<!-- END .latest-event-item -->
									</div>
									
									<!-- BEGIN .latest-event-item -->
									<div class="latest-event-item last">
										<h3><a href="#">Maecenas enim enim, bibendum in dictum id, pellentesque  sapien</a></h3>
										<p>Phasellus urna sem, scelerisque ac porta a, fringilla non neque. Mauris lacus eros, faucibus quis rhoncus.</p>
										<a href="#" class="more-link">Read more</a>
									<!-- END .latest-event-item -->
									</div>
									
								<!-- END .latest-events -->
								</div>
								
							</div>
						<!-- END .block-1 -->
						</div>
						
						
						<!-- BEGIN .section-spacer -->
						<table class="section-spacer">
							<tr>
								<td class="left"></td>
								<td class="middle">
									<span>Advertisement</span>
									<!-- <img src="images/ico-bullet-3.png" alt="Advertisement" /> -->
								</td>
								<td class="right"></td>
							</tr>
						<!-- END .section-spacer -->
						</table>
						
						
						<!-- BEGIN .ad-250x250 -->
						<div class="ad-250x250">
							<a href="#"><img src="images/image-9.jpg" alt="" /></a>
						<!-- END .ad-250x250 -->
						</div>
						
						
						<!-- BEGIN .block-1 -->
						<div class="block-1">
							<h2><span>Latest articles</span><a href="#"><b>show all</b></a></h2>
							<div class="block-1-content">
								
								<!-- BEGIN .latest-articles -->
								<div class="latest-articles">
								
									<!-- BEGIN .latest-article-item -->
									<div class="latest-article-item">
										<table>
											<tr>
												<td class="image"><a href="#"><img src="images/image-2.jpg" alt="Maecenas pretium facilisis lectus sed molestie" /></a></td>
												<td class="text">
													<h3><a href="#">Maecenas pretium facilisis lectus</a></h3>
													<a href="#" class="more-link">Read more</a>
												</td>
											</tr>
										</table>
									<!-- END .latest-article-item -->
									</div>
									
									<!-- BEGIN .latest-article-item -->
									<div class="latest-article-item">
										<table>
											<tr>
												<td class="image"><a href="#"><img src="images/image-3.jpg" alt="Suspendisse in arcu urna eget fermentum" /></a></td>
												<td class="text">
													<h3><a href="#">Suspendisse in arcu urna eget fermentum</a></h3>
													<a href="#" class="more-link">Read more</a>
												</td>
											</tr>
										</table>
									<!-- END .latest-article-item -->
									</div>
									
									<!-- BEGIN .latest-article-item -->
									<div class="latest-article-item">
										<table>
											<tr>
												<td class="image"><a href="#"><img src="images/image-10.jpg" alt="Aenean porttitor dui ac dolor semper convallis" /></a></td>
												<td class="text">
													<h3><a href="#">Aenean porttitor dui ac dolor semper convallis</a></h3>
													<a href="#" class="more-link">Read more</a>
												</td>
											</tr>
										</table>
									<!-- END .latest-article-item -->
									</div>
									
									<!-- BEGIN .latest-article-item -->
									<div class="latest-article-item last">
										<table>
											<tr>
												<td class="image"><a href="#"><img src="images/image-4.jpg" alt="Nulla euismod cursus sem ultrices massa adipiscing" /></a></td>
												<td class="text">
													<h3><a href="#">Nulla euismod cursus sem ultrices massa</a></h3>
													<a href="#" class="more-link">Read more</a>
												</td>
											</tr>
										</table>
									<!-- END .latest-article-item -->
									</div>
																	
								<!-- END .latest-articles -->
								</div>	
								
							</div>
						<!-- END .block-1 -->
						</div>
						
					
					<!-- END .right-side -->
					</div>


				<!-- END .content -->
				</div>
				
			<!-- END .content-wrapper -->
			</div>
			
			
			<div class="clear-footer"></div>
			
		<!-- END .container -->
		</div>
		
		
		<!--start F O O T E R    S E C T I O N-->
		<?php
		include("inc/footer.php");
		?>
		
		<!--end F O O T E R    S E C T I O N-->

	</body>
</html>