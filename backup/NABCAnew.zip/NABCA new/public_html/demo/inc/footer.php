<!-- BEGIN .footer-wrapper -->
		<div class="footer-wrapper">
		
			<!-- BEGIN .footer -->
			<div class="footer">
			
				<!-- BEGIN .cross-hill -->
				<span class="cross-hill">&nbsp;</span>
				<!-- END .cross-hill -->

				<table>
					<tr>
					
						<td>
							<h2>Contact Information</h2>
							<span class="phone">+713 446 2807 </span> <a href="mailto:info@nabcaonline.org" class="email">info@nabcaOnline.org</a>
                            <p>Address goes here </p></td>
						
						<td class="spacer"></td>
						
						<td>
							<h2>Shortcuts</h2>
							<ul>
								<li><a href="#">Read Our <b>Journal</b></a></li>
								<li><a href="#">View Newest Photos In Our <b>Gallery</b></a></li>
								<li><a href="#">List Of Our <b>Ministries</b></a></li>
								<li><a href="#">Link To Your <b>Custom Section</b></a></li>
							</ul>
						</td>
						
						<td class="spacer"></td>
						
						<td>
							<h2>Social Contacts</h2>
							<ul>
								<li class="facebook"><a href="#">Friend Us On <b>Facebook</b></a></li>
								<li class="twitter"><a href="#">Follow Us On <b>Twitter</b></a></li>
								<li class="digg"><a href="#">Dig Our Posts On <b>Digg</b></a></li>
								<li class="rss"><a href="#">Subscribe To Our <b>RSS</b> Feed</a></li>
							</ul>
						</td>
						
					</tr>
				</table>
				
			<!-- END .footer -->
			</div>
		
		<!-- END .footer-wrapper -->
		</div>
		
		
		<!-- BEGIN .footer-wrapper-2 -->
		<div class="footer-wrapper-2">
			
			<!-- BEGIN .footer-2 -->
			<div class="footer-2">
			
				<div class="left"><? echo $footer ?></div>
				
				<div class="right">
					Design by <b><a href="<? echo $siteDesignURL ?>" target="_blank"><? echo $siteDesign ?></a></b>				</div>
			
			    <!-- END .footer-2 -->
			</div>
			
		<!-- END .footer-wrapper-2 -->
		</div>