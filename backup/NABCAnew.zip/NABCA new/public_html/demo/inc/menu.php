					<ul>
						<li class="menu-item"><a href="index2.php"><i>Home</i></a></li>
						
						<li class="menu-item">
							<a href="#"><i><span>About NABCA</span></i></a>
							<ul>
								<li class="menu-item"><a href="history.php"><i>History</i></a></li>
								<li class="menu-item"><a href="#"><i>Present Day</i></a></li>
								<li class="menu-item"><a href="#"><i>Purpose</i></a></li>
								<li class="menu-item"><a href="#"><i>Goals</i></a></li>
								<li class="menu-item"><a href="#"><i>Proclamation</i></a></li>
								<li class="menu-item"><a href="#"><i>Contact Us</i></a></li>

												
							</ul>
						</li>
						<li class="menu-item">
							<a href="#"><i><span>Leadership</span></i></a>
							<ul>
								<li class="menu-item"><a href="#"><i>Officers</i></a></li>
								
								<li class="menu-item">
									<a href="#"><i><span>Regions</span></i></a>
									<ul>
										<li class="menu-item"><a href="#"><i>Region One</i></a></li>
										<li class="menu-item"><a href="#"><i>Region Two</i></a></li>
										<li class="menu-item"><a href="#"><i>Region Three</i></a></li>	
									</ul>
								</li>
															
							</ul>
						</li>
						
						<li class="menu-item">
							<a href="#"><i><span>Information</span></i></a>
							<ul>
								<li class="menu-item"><a href="#"><i>Quarterly Newsletter</i></a></li>
								<li class="menu-item"><a href="#"><i>Calendar of Events</i></a></li>
								<li class="menu-item"><a href="#"><i>Major National Events</i></a></li>
								<li class="menu-item"><a href="#"><i>Church Documents</i></a></li>
								<li class="menu-item"><a href="#"><i>Links</i></a></li>
								
							</ul>
						</li>
						
						<li class="menu-item">
							<a href="#"><i><span>Events</span></i></a>
							<ul>
								<li class="menu-item"><a href="#"><i>Calendar of Events</i></a></li>
								<li class="menu-item"><a href="#"><i>Major National Events</i></a></li>
								
								
							</ul>
						</li>
						
						<li class="menu-item">
							<a href="#"><i><span>Gallery</span></i></a>
							<ul>
								<li class="menu-item"><a href="#"><i>Photos</i></a></li>
								<li class="menu-item"><a href="#"><i>Video</i></a></li>
								
								
							</ul>
						</li>
						
						
					</ul>
