<div class="menu-primary">
				
					<span class="rosary">&nbsp;</span>
				
					<ul>
						<li class="menu-item"><a href="homepage.html"><i>Homepage</i></a></li>
						<li class="menu-item"><a href="blog.html"><i>Our Journal</i></a></li>
						<li class="menu-item">
							<a href="#"><i><span>Media</span></i></a>
							<ul>
								<li class="menu-item"><a href="gallery.html"><i>Photo Gallery</i></a></li>
								<li class="menu-item"><a href="gallery-open.html"><i>Single Open Photo</i></a></li>
								<li class="menu-item"><a href="full-width.html"><i>Full Width Page</i></a></li>
								<li class="menu-item"><a href="post.html"><i>Open Journal Entry</i></a></li>

								<li class="menu-item">
									<a href="#"><i><span>Second Level Menu</span></i></a>
									<ul>
										<li class="menu-item"><a href="#"><i>Your Menu Item Goes Here</i></a></li>
										<li class="menu-item"><a href="#"><i>Your Menu Item Goes Here</i></a></li>
										<li class="menu-item"><a href="#"><i>Your Menu Item Goes Here</i></a></li>	
									</ul>
								</li>
								
							</ul>
						</li>
						<li class="menu-item">
							<a href="#"><i><span>Ministries</span></i></a>
							<ul>
								<li class="menu-item"><a href="ministries-single-column-view.html"><i>Single Column View</i></a></li>
								<li class="menu-item"><a href="ministries-two-column-view.html"><i>Two Column View</i></a></li>
								<li class="menu-item"><a href="ministries-three-column-view.html"><i>Three Column View</i></a></li>								
							</ul>
						</li>
						<li class="menu-item">
							<a href="#"><i><span>Shortcodes</span></i></a>
							<ul>
								<li class="menu-item"><a href="shortcodes-buttons.html"><i>Buttons</i></a></li>
								<li class="menu-item"><a href="shortcodes-quotes.html"><i>Quotes</i></a></li>
								<li class="menu-item"><a href="shortcodes-spacers.html"><i>Spacers</i></a></li>
								<li class="menu-item"><a href="shortcodes-contact-form.html"><i>Contact Form</i></a></li>
								<li class="menu-item"><a href="shortcodes-lists.html"><i>Lists</i></a></li>
								<li class="menu-item"><a href="shortcodes-layouts.html"><i>Text Layouts</i></a></li>
							</ul>
						</li>
					</ul>
