			<!-- BEGIN .header-wrapper -->
			<div class="header-wrapper">
			
				<!-- BEGIN .header -->
				<div class="header">
				
					<!-- BEGIN .doves -->
					<span class="doves">&nbsp;</span>
					<!-- END .doves -->
				
					<!-- BEGIN .logo -->
					<div class="logo">
						<h1><a href="#"><img src="img/logo02.png" alt="Ray Of Light - WordPress Theme For Religious Movements And Churches" width="258" height="55" /></a></h1>
						<!-- <h1><a href="#">Your Page Name Goes Here</a></h1> -->
					<!-- END .logo -->
					</div>
					
					<!-- BEGIN .header-right -->
					<div class="header-right">
					
						<!-- BEGIN .searchform -->
						<form action="#" class="searchform">
							<input type="text" class="input-text" value="search here" onfocus="if (this.value == 'search here') {this.value = '';};" />
							<input type="image" src="images/blank.png" class="input-button" value="Search!" />
						<!-- END .searchform -->
						</form>

					<!-- END .header-right -->
					</div>
					
				<!-- END .header -->	
				</div>
				
			<!-- END .header-wrapper -->
			</div>