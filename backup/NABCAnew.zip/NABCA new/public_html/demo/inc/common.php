<?php
$pageTitle = "  ||  NABCA || National Association of Black Catholic Administrators";
$footer = "Copyright &copy; 2011 <b>National Association of Black Catholic Administrators</b>";
$siteDesign = "Jade 7";
$siteDesignURL = "http://www.jade7.com";


?>