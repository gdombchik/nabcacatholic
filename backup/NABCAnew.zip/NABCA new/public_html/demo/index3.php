<?php
include("inc/common.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<!-- BEGIN html -->
<html xmlns="http://www.w3.org/1999/xhtml">

	<!-- BEGIN head -->
	<head>
	
		<!-- Title -->
		<title>Home<? echo $pageTitle ?> </title>
		
		<!-- Meta Tags -->
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		
		<!-- Favicon -->
		<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />
		
		<!-- Stylesheets -->
		<link rel="stylesheet" href="css/style.css" type="text/css" />
		
		<!-- JavaScripts -->
		<script src="js/cufon-yui.js" type="text/javascript"></script>
		<script src="js/chaparralpro.font.js" type="text/javascript"></script>
		
		<script type="text/javascript">
			Cufon.replace('.title', { textShadow: '#fff 0 1px', hover: 'true' } );
			Cufon.replace('.menu-item a', { textShadow: '#110d0b 0 1px', hover: 'true' } );
			Cufon.replace('.block-1 h2 span', { textShadow: '#fff 0 1px' } );
			Cufon.replace('.block-2 h2 span', { textShadow: '#fff 0 1px' } );
			Cufon.replace('.footer-wrapper .footer table h2', { textShadow: '#201913 0 1px' } );
		</script>

		<!--[if lte IE 7]>
		<style type="text/css">
			html .jqueryslidemenu { height: 1%; } /* Holly Hack for IE7 and below */
		</style>
		<![endif]-->
		<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script> 
		<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
		<script type="text/javascript" src="js/jquery.scrollTo-min.js"></script>
		<script type="text/javascript" src="js/aktuals.js"></script>
		<script type="text/javascript" src="js/jqueryslidemenu.js"></script>
	<!-- END head -->
	</head>
	
	<!-- BEGIN body -->
	<body>


		<!-- BEGIN .container -->
		<div class="container">
		
		<!-- begin  H E A D E R    S E C T I O N -->

		<?php include("inc/header.php"); ?>
			
		<!-- end  H E A D E R    S E C T I O N -->
			
			<!-- BEGIN .menu-primary-wrapper -->
			<div class="menu-primary-wrapper">
			
			
				<!-- BEGIN .menu-primary -->
				<div class="menu-primary">
				
					<span class="rosary">&nbsp;</span>
				<? include("inc/menu.php"); ?>
					
					<!-- BEGIN .social -->
					<? include("inc/social.php"); ?>
					<!-- END .social -->

				<!-- END .menu-primary -->
				</div>


			<!-- END .menu-primary-wrapper -->
			</div>


			<!-- BEGIN .content-wrapper -->
			<div class="content-wrapper">
			
				<!-- BEGIN .content -->
				<div class="content">
				
				
					<!-- BEGIN .homepage-wrapper -->
					<div class="homepage-wrapper">


						<!-- BEGIN .homepage-slider -->
						<div class="homepage-slider">
							
							<span class="tag">&nbsp;</span>
							<span class="rounded-corners">&nbsp;</span>
							<div id="aktuals_field" style="overflow:hidden; position:relative;width:900px;"> 
							<table>
								<tr>
								
									<td>
										<!-- BEGIN .homepage-slider-item -->
										<div id="aktuals1" class="homepage-slider-item" style="background: url(images/image-1.jpg) 0 0 no-repeat;">
											<p><a href="#" class="title">Announcement can go here</a></p>
											<p><a href="#" class="description">With a detailed description to follow...</a></p>
										<!-- END .homepage-slider-item -->
										</div>
									</td>
									
									<td>
										<!-- BEGIN .homepage-slider-item -->
										<div id="aktuals2" class="homepage-slider-item" style="background: url(images/image-51.jpg) 0 0 no-repeat;">
												<p><a href="#" class="title">Cras vulputate dui at felis varius et tur risus viverra</a></p>
												<p><a href="#" class="description">Suspendisse a nunc nulla. In accumsan enim a nisi tempor quis bibendum lacus mattis. Curabitur adipiscing nulla quis augue luctus volutpat.</a></p>									
											<div class="background"></div>
										<!-- END .homepage-slider-item -->
										</div>
									</td>
									
									<td>
										<!-- BEGIN .homepage-slider-item -->
										<div  id="aktuals3" class="homepage-slider-item" style="background: url(images/image-52.jpg) 0 0 no-repeat;">
												<p><a href="#" class="title">Aenean quis sem sit amet quam laoreet tristiquem auris convallis</a></p>
												<p><a href="#" class="description">Vestibulum cursus diam vel magna tristique sodales. Nullam fermentum nibh vitae nisl sodales in blandit sem euismod. Aliquam erat volutpat. Nulla facilisi.</a></p>
											<div class="background"></div>
										<!-- END .homepage-slider-item -->
										</div>
									</td>
									
									<td>
										<!-- BEGIN .homepage-slider-item -->
										<div id="aktuals4" class="homepage-slider-item" style="background: url(images/image-53.jpg) 0 0 no-repeat;">
												<p><a href="#" class="title">Duis porttitor arcu vitae magna viverra vel imperdiet</a></p>
												<p><a href="#" class="description">Donec et ligula sed metus euismod ultrices. Pellentesque ullamcorper velit in tellus luctus hendrerit sed eu enim.</a></p>
											<div class="background"></div>
										<!-- END .homepage-slider-item -->
										</div>
									</td>
									
									<td>
										<!-- BEGIN .homepage-slider-item -->
										<div  id="aktuals5" class="homepage-slider-item" style="background: url(images/image-54.jpg) 0 0 no-repeat;">
												<p><a href="#" class="title">Aliquam et tortor at tellus dapibus luctus</a></p>
												<p><a href="#" class="description">Praesent id arcu nec urna iaculis gravida ac ut sapien. Duis et metus id ligula convallis pulvinar. Quisque et libero sit amet erat euismod blandit.</a></p>
											<div class="background"></div>
										<!-- END .homepage-slider-item -->
										</div>
									</td>

								</tr>
							</table>
							</div>
							
							
							<!-- BEGIN .homepage-slider-image-shadow -->
							<div class="homepage-slider-image-shadow">
								&nbsp;
							<!-- END .homepage-slider-image-shadow -->
							</div>
							
							
							<!-- BEGIN .navigation -->
							<div class="navigation">
								<a href="#" class="previous" onmouseover="set_hover_on();" onmouseout="set_hover_off();" onclick="scrollLefty(); return false;"></a>
								<a href="#" id="aktuals1_btn" onclick="scrollToElem(1); return false;" class="active"></a>
								<a href="#" id="aktuals2_btn" onclick="scrollToElem(2); return false;"></a>
								<a href="#" id="aktuals3_btn" onclick="scrollToElem(3); return false;"></a>
								<a href="#" id="aktuals4_btn" onclick="scrollToElem(4); return false;"></a>
								<a href="#" id="aktuals5_btn" onclick="scrollToElem(5); return false;"></a>
								<a href="#" class="next" onmouseover="set_hover_on();" onmouseout="set_hover_off();" onclick="scrollRight(); return false;"></a>
							<!-- END .navigation -->
							</div>
							

						<!-- END .homepage-slider -->
						</div>
						
						
						<!-- BEGIN .homepage-columns -->
						<div class="homepage-columns">
						
							<!-- BEGIN .homepage-columns-item -->
							<div class="homepage-columns-item">
								<div class="title">
									<div style="background: url(images/ico-our-work-1.png) center left no-repeat;">Purpose </div>
								</div>
								<div class="text">
									<p>NABCA is dedicated to providing a forum for African American Catholic Administrators to gather and share their collective . . . </p>
									<p><a href="purpose.php" class="more-link">Read more</a></p>
							  </div>
							<!-- END .homepage-columns-item -->
							</div>
							
							<!-- BEGIN .homepage-columns-item -->
							<div class="homepage-columns-item">
								<div class="title">
									<div style="background: url(images/ico-believes-1.png) center left no-repeat;">Goals</div>
								</div>
								<div class="text">
									<p>Evangelization, leadership skills development, collaboration with similar organizations, and crafting strategies for  . . .</p>
									<p><a href="goals.php" class="more-link">Read more</a></p>
							  </div>
							<!-- END .homepage-columns-item -->
							</div>
							
							<!-- BEGIN .homepage-columns-item -->
							<div class="homepage-columns-item">
								<div class="title">
									<div style="background: url(images/ico-compasion-1.png) center left no-repeat;">Proclamation</div>
								</div>
								<div class="text">
									<p>This year America marks the fiftieth anniversary of the beginning of an important part of the civil rights movement . . . </p>
									<p><a href="proclamation.php" class="more-link">Read more</a></p>
							  </div>
							<!-- END .homepage-columns-item -->
							</div>
							
							<!-- BEGIN .homepage-columns-item -->
							<div class="homepage-columns-item last">
								<div class="title">
									<div style="background: url(images/ico-our-church-1.png) center left no-repeat;">The Church </div>
								</div>
								<div class="text">
									<p>Phasellus eu malesuada ipsum. Integer adipiscing, lacus fermentum mollis suscipit, felis nibh dapibus purus, sit amet.</p>
									<p><a href="#" class="more-link">Read more</a></p>
								</div>
							<!-- END .homepage-columns-item -->
							</div>
						
						<!-- END .homepage-columns -->
						</div>
						
						
						<!-- BEGIN .homepage-spacer -->
						<div class="homepage-spacer">
							&nbsp;
						<!-- END .homepage-spacer -->
						</div>
						
						
						<!-- BEGIN .homepage-footer -->
						<div class="homepage-footer">
							
							
							<!-- BEGIN .block-2 -->
							<div class="block-2 last">
								<h2><span>About NABCA </span><!-- <img src="images/ico-bullet-3.png" alt="About Ray Of Light Theme For WordPress" /> --></h2>
								<div class="block-2-content">
									
									<!-- BEGIN .homepage-about -->
									<div class="homepage-about">
									
										<p class="caps">As with all  organizations, several years preceded the formal establishment of the National  Association of Black Catholic Administrators [NABCA]. Between 1970 and 1976,  Diocesan Bishops opened Offices for Black Ministry [OBMs] in Detroit,  Rochester, Cincinnati,  Pittsburgh, Washington,  DC, and Houston.  Garland Jaggers, Detroit’s Director, and Father  Jerome Robinson, OP, Rochester’s  Director, gave birth to the idea for a gathering of OBM Directors for mutual  support and sharing. Five Directors had the first recorded meeting of the Black  Catholic Administrators on October 7 and 8, 1976 in Rochester, NY.  Diocesan Black Catholic leadership was necessary to impact Diocesan structures  and policies from within. They were surviving in unwelcoming and sometimes  hostile Diocesan structures, and among some disapproving African American  Catholics.</p>
								
										<p><a href="history.php" class="more-link">Read more</a></p>
																		
									<!-- END .homepage-about -->
								  </div>	
									
								</div>
							<!-- END .block-2 -->
							</div>


							<!-- BEGIN .block-1 -->
							<div class="block-1 last">
								<h2><span>Latest Entries</span><a href="#"><b>show all</b></a></h2>
								<div class="block-1-content">
									
									<!-- BEGIN .latest-articles -->
									<div class="latest-articles">
									
										<!-- BEGIN .latest-article-item -->
										<div class="latest-article-item">
											<table>
												<tr>
													<td class="image"><a href="#"><img src="images/image-2.jpg" alt="Maecenas pretium facilisis lectus sed molestie" /></a></td>
													<td class="text">
														<h3><a href="#">Maecenas pretium facilisis lectus</a></h3>
														<a href="#" class="more-link">Read more</a>
													</td>
												</tr>
											</table>
										<!-- END .latest-article-item -->
										</div>
										
										<!-- BEGIN .latest-article-item -->
										<div class="latest-article-item">
											<table>
												<tr>
													<td class="image"><a href="#"><img src="images/image-3.jpg" alt="Suspendisse in arcu urna eget fermentum" /></a></td>
													<td class="text">
														<h3><a href="#">Suspendisse in arcu urna eget fermentum</a></h3>
														<a href="#" class="more-link">Read more</a>
													</td>
												</tr>
											</table>
										<!-- END .latest-article-item -->
										</div>
										
										<!-- BEGIN .latest-article-item -->
										<div class="latest-article-item last">
											<table>
												<tr>
													<td class="image"><a href="#"><img src="images/image-4.jpg" alt="Nulla euismod cursus sem ultrices massa adipiscing" /></a></td>
													<td class="text">
														<h3><a href="#">Nulla euismod cursus sem ultrices massa</a></h3>
														<a href="#" class="more-link">Read more</a>
													</td>
												</tr>
											</table>
										<!-- END .latest-article-item -->
										</div>
																		
									<!-- END .latest-articles -->
									</div>	
									
								</div>
							<!-- END .block-1 -->
							</div>


						<!-- END .homepage-footer -->
						</div>
						
						
					<!-- END .homepage-wrapper -->
					</div>


				<!-- END .content -->
				</div>
				
			<!-- END .content-wrapper -->
			</div>
			
			
			<div class="clear-footer"></div>
			
		<!-- END .container -->
		</div>
		
		<!--start F O O T E R    S E C T I O N-->
		<?php
		include("inc/footer.php");
		?>
		
		<!--end F O O T E R    S E C T I O N-->


	</body>
</html>